################################################################################
# Information about configuration files present in the same directory #
################################################################################
"792e9e5f-15e9-4d56-af5a-7e5cd118643e/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"792e9e5f-15e9-4d56-af5a-7e5cd118643e/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"792e9e5f-15e9-4d56-af5a-7e5cd118643e/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
